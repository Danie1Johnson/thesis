latex thesis
bibtex thesis
latex thesis
latex thesis
dvipdf thesis
./clean.sh
