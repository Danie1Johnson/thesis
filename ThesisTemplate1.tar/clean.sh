rm *.{aux,lot,lof,toc,cb,bbl,blg}
